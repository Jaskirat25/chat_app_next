
        export const CometChatSettings = {
  "chatFeatures": {
    "coreMessagingExperience": {
      "typingIndicator": true,
      "threadConversationAndReplies": true,
      "photosSharing": true,
      "videoSharing": true,
      "audioSharing": true,
      "fileSharing": true,
      "editMessage": true,
      "deleteMessage": true,
      "messageDeliveryAndReadReceipts": true,
      "userAndFriendsPresence": true,
      "conversationAndAdvancedSearch": true,
      "moderation": true,
      "quotedReplies": false,
      "markAsUnread": false,
      "richTextFormatting": true
    },
    "deeperUserEngagement": {
      "mentions": true,
      "mentionAll": true,
      "reactions": true,
      "messageTranslation": true,
      "polls": true,
      "collaborativeWhiteboard": true,
      "collaborativeDocument": true,
      "voiceNotes": true,
      "emojis": true,
      "stickers": true,
      "userInfo": true,
      "groupInfo": true
    },
    "aiUserCopilot": {
      "conversationStarter": false,
      "conversationSummary": false,
      "smartReply": false
    },
    "userManagement": {
      "friendsOnly": false
    },
    "groupManagement": {
      "createGroup": true,
      "addMembersToGroups": true,
      "joinLeaveGroup": true,
      "deleteGroup": true,
      "viewGroupMembers": true
    },
    "moderatorControls": {
      "kickUsers": true,
      "banUsers": true,
      "promoteDemoteMembers": true,
      "reportMessage": true
    },
    "privateMessagingWithinGroups": {
      "sendPrivateMessageToGroupMembers": true
    },
    "inAppSounds": {
      "incomingMessageSound": true,
      "outgoingMessageSound": true
    }
  },
  "callFeatures": {
    "voiceAndVideoCalling": {
      "oneOnOneVoiceCalling": true,
      "oneOnOneVideoCalling": true,
      "groupVideoConference": false,
      "groupVoiceConference": false
    }
  },
  "layout": {
    "withSideBar": true,
    "tabs": [
      "chats",
      "calls",
      "users",
      "groups"
    ],
    "chatType": "user",
    "compactMessageComposer": false
  },
  "style": {
    "theme": "system",
    "color": {
      "brandColor": "#6852D6",
      "primaryTextLight": "#141414",
      "primaryTextDark": "#FFFFFF",
      "secondaryTextLight": "#727272",
      "secondaryTextDark": "#989898"
    },
    "typography": {
      "font": "arial",
      "size": "default"
    }
  },
  "noCode": {
    "docked": false,
    "styles": {
      "buttonBackGround": "#141414",
      "buttonShape": "rounded",
      "openIcon": "https://cdn.jsdelivr.net/npm/@cometchat/chat-embed@latest/dist/icons/docked_open_icon.svg",
      "closeIcon": "https://cdn.jsdelivr.net/npm/@cometchat/chat-embed@latest/dist/icons/docked_close_icon.svg",
      "customJs": "",
      "customCss": "",
      "dockedAlignment": "right"
    }
  },
  "agent": {
    "chatHistory": true,
    "newChat": true,
    "agentIcon": "",
    "showAgentIcon": true
  }
};
      